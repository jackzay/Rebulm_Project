<!DOCTYPE html>
<html lang="en">
<head>
    <title>Cinema A Entertainment Category Flat Bootstarp Resposive Website Template | Home :: w3layouts</title>
    <link href="<?php echo e(asset('/css/bootstrap.css')); ?>" rel='stylesheet' type='text/css' />
    <!-- Custom Theme files -->
    <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
    <!-- Custom Theme files -->
    <script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
    
    
    <!-- Custom Theme files -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Cinema Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
    Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!--webfont-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
    
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\Rebulm_Project\Rebulm_Project\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>